# 🚛 LogiFlete - Plataforma de Fletes y Logística B2B/C2C

Plataforma autónoma para la gestión de fletes y planificación de viajes de camiones particulares[span_4](start_span)[span_4](end_span). Conecta **Dadores de Carga** con **Transportistas** mediante geolocalización en tiempo real (Leaflet + OpenStreetMap / PostGIS), pagos bajo custodia (Escrow 30/70 con comisión del 5%) y notificaciones en ruta vía FCM[span_5](start_span)[span_5](end_span)[span_6](start_span)[span_6](end_span)[span_7](start_span)[span_7](end_span).

## 🚀 Inicio Rápido (Entorno de Desarrollo)

### Prerrequisitos
- Docker & Docker Compose[span_8](start_span)[span_8](end_span)
- Node.js >= 18 (para Cloud Functions y desarrollo local)[span_9](start_span)[span_9](end_span)[span_10](start_span)[span_10](end_span)
- Firebase CLI (`npm install -g firebase-tools`)[span_11](start_span)[span_11](end_span)

### 1. Clonar e Iniciar Backend con Docker (FastAPI + PostgreSQL/PostGIS)
```bash
git clone [https://github.com/tu-usuario/logiflete-app.git](https://github.com/tu-usuario/logiflete-app.git)
cd logiflete-app
cp .env.example .env
docker-compose up -d --build
