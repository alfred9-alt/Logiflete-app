import React, { useState } from 'react';
import { StyleSheet, View, Button, SafeAreaView, StatusBar } from 'react-native';
import DriverFeed from './src/screens/DriverFeed';
import CreateTripScreen from './src/screens/CreateTripScreen';
import InvoiceScreen from './src/screens/InvoiceScreen';

export default function App() {
  // Estado para alternar entre vistas ('feed' | 'create' | 'invoice')
  const [currentView, setCurrentView] = useState('feed');

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f2f4f7" />
      
      {/* Botones de navegación superior para pruebas */}
      <View style={styles.navBar}>
        <View style={styles.navButton}>
          <Button 
            title="Ver Cargas" 
            onPress={() => setCurrentView('feed')} 
            color={currentView === 'feed' ? '#007AFF' : '#888'}
          />
        </View>

        <View style={styles.navButton}>
          <Button 
            title="Publicar Flete" 
            onPress={() => setCurrentView('create')} 
            color={currentView === 'create' ? '#007AFF' : '#888'}
          />
        </View>

        <View style={styles.navButton}>
          <Button 
            title="Cargar Factura" 
            onPress={() => setCurrentView('invoice')} 
            color={currentView === 'invoice' ? '#007AFF' : '#888'} 
          />
        </View>
      </View>

      {/* Renderizado condicional de pantallas */}
      <View style={styles.content}>
        {currentView === 'feed' && <DriverFeed />}
        {currentView === 'create' && <CreateTripScreen />}
        {currentView === 'invoice' && <InvoiceScreen />}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f4f7' },
  navBar: { flexDirection: 'row', justifyContent: 'space-around', padding: 10, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#ddd' },
  navButton: { flex: 1, marginHorizontal: 5 },
  content: { flex: 1 }
});
