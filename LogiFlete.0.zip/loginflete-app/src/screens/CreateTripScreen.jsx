import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { createTrip } from '../api/tripService';

export default function CreateTripScreen({ navigation }) {
  const [form, setForm] = useState({
    origin: '',
    destination: '',
    cargo_type: '',
    required_trailer_type: 'BATEA', // Valor por defecto
    weight_tons: '',
    offered_price: '',
    origin_lat: '-27.6500', // Coordenadas de ejemplo (Coronel Du Graty / Chaco)
    origin_lng: '-61.1500',
  });

  const [loading, setLoading] = useState(false);

  const handleChange = (name, value) => {
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async () => {
    if (!form.origin || !form.destination || !form.cargo_type || !form.weight_tons || !form.offered_price) {
      Alert.alert('Error', 'Por favor, completa todos los campos obligatorios.');
      return;
    }

    const weight = parseFloat(form.weight_tons.replace(',', '.'));
    const price = parseFloat(form.offered_price.replace(',', '.'));

    if (isNaN(weight) || weight <= 0 || isNaN(price) || price <= 0) {
      Alert.alert('Error', 'El peso y la tarifa deben ser valores numéricos válidos mayores a 0.');
      return;
    }

    try {
      setLoading(true);
      const payload = {
        ...form,
        weight_tons: weight,
        offered_price: price,
        origin_lat: parseFloat(form.origin_lat),
        origin_lng: parseFloat(form.origin_lng),
      };

      const response = await createTrip(payload);
      Alert.alert('¡Éxito!', response.message || 'Flete publicado correctamente.');
      
      setForm({
        origin: '',
        destination: '',
        cargo_type: '',
        required_trailer_type: 'BATEA',
        weight_tons: '',
        offered_price: '',
        origin_lat: '-27.6500',
        origin_lng: '-61.1500',
      });
    } catch (err) {
      Alert.alert('Error al publicar', err.detail || err.message || 'No se pudo registrar el viaje.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.headerTitle}>📦 Publicar Nuevo Flete</Text>

      <Text style={styles.label}>Origen</Text>
      <TextInput
        style={styles.input}
        placeholder="Ej: Corzuela, Chaco"
        value={form.origin}
        onChangeText={(val) => handleChange('origin', val)}
      />

      <Text style={styles.label}>Destino</Text>
      <TextInput
        style={styles.input}
        placeholder="Ej: Puerto Rosario, Santa Fe"
        value={form.destination}
        onChangeText={(val) => handleChange('destination', val)}
      />

      <Text style={styles.label}>Tipo de Carga</Text>
      <TextInput
        style={styles.input}
        placeholder="Ej: Soja a granel"
        value={form.cargo_type}
        onChangeText={(val) => handleChange('cargo_type', val)}
      />

      <Text style={styles.label}>Tipo de Acople Requerido</Text>
      <TextInput
        style={styles.input}
        placeholder="Ej: BATEA, SIDER, CHASIS"
        value={form.required_trailer_type}
        onChangeText={(val) => handleChange('required_trailer_type', val)}
      />

      <Text style={styles.label}>Peso (Toneladas)</Text>
      <TextInput
        style={styles.input}
        placeholder="Ej: 28.5"
        keyboardType="numeric"
        value={form.weight_tons}
        onChangeText={(val) => handleChange('weight_tons', val)}
      />

      <Text style={styles.label}>Tarifa Ofrecida ($)</Text>
      <TextInput
        style={styles.input}
        placeholder="Ej: 350000"
        keyboardType="numeric"
        value={form.offered_price}
        onChangeText={(val) => handleChange('offered_price', val)}
      />

      <TouchableOpacity style={styles.button} onPress={handleSubmit} disabled={loading}>
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.buttonText}>Publicar Carga</Text>
        )}
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, backgroundColor: '#f2f4f7', flexGrow: 1 },
  headerTitle: { fontSize: 22, fontWeight: 'bold', textAlign: 'center', marginBottom: 20, color: '#1a1a1a' },
  label: { fontSize: 14, fontWeight: '600', color: '#333', marginBottom: 6 },
  input: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#ddd', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, fontSize: 15, marginBottom: 14 },
  button: { backgroundColor: '#007AFF', borderRadius: 8, paddingVertical: 14, alignItems: 'center', marginTop: 10 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' }
});
