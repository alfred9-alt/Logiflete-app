import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, TouchableOpacity, View, Alert } from 'react-native';
import { registerInvoice } from '../api/invoiceService';

export default function InvoiceScreen({ route }) {
  const { freightId, issuerId } = route.params || {};
  
  const [pointOfSale, setPointOfSale] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [cae, setCae] = useState('');
  const [totalAmount, setTotalAmount] = useState('');

  const handleSubmit = async () => {
    const pos = parseInt(pointOfSale, 10);
    const invNum = parseInt(invoiceNumber, 10);
    const numericTotal = parseFloat(totalAmount.replace(',', '.'));

    if (isNaN(pos) || pos <= 0 || isNaN(invNum) || invNum <= 0) {
      Alert.alert("Error de validación", "Ingresá un Punto de Venta y Número de Factura válidos.");
      return;
    }

    if (cae.trim().length !== 14) {
      Alert.alert("Error de validación", "El CAE debe tener exactamente 14 dígitos.");
      return;
    }

    if (isNaN(numericTotal) || numericTotal <= 0) {
      Alert.alert("Error de validación", "Ingresá un Monto Total válido mayor a 0.");
      return;
    }

    try {
      const netAmount = Number((numericTotal / 1.21).toFixed(2));
      const vatAmount = Number((numericTotal - netAmount).toFixed(2));

      const payload = {
        freight_id: freightId,
        issuer_id: issuerId,
        invoice_type: 'FACTURA_A',
        point_of_sale: pos,
        invoice_number: invNum,
        cae: cae.trim(),
        net_amount: netAmount,
        vat_amount: vatAmount,
        total_amount: numericTotal,
        issue_date: new Date().toISOString().split('T')[0],
      };

      const result = await registerInvoice(payload);
      Alert.alert("¡Éxito!", result.message);
    } catch (error) {
      Alert.alert("Error de validación", error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Cargar Factura de Flete</Text>
      
      <TextInput 
        style={styles.input} 
        placeholder="Punto de Venta (ej. 1)" 
        keyboardType="numeric"
        value={pointOfSale}
        onChangeText={setPointOfSale}
      />
      
      <TextInput 
        style={styles.input} 
        placeholder="Número de Factura (ej. 154)" 
        keyboardType="numeric"
        value={invoiceNumber}
        onChangeText={setInvoiceNumber}
      />

      <TextInput 
        style={styles.input} 
        placeholder="CAE (14 dígitos)" 
        keyboardType="numeric"
        maxLength={14}
        value={cae}
        onChangeText={setCae}
      />

      <TextInput 
        style={styles.input} 
        placeholder="Monto Total (ARS)" 
        keyboardType="numeric"
        value={totalAmount}
        onChangeText={setTotalAmount}
      />

      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Validar y Enviar Factura</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center', backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 12, borderRadius: 8, marginBottom: 15 },
  button: { backgroundColor: '#007AFF', padding: 15, borderRadius: 8, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 }
});
