import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, FlatList, ActivityIndicator, SafeAreaView } from 'react-native';
import { getAvailableTrips } from '../api/tripService';

export default function DriverFeed() {
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchTrips();
  }, []);

  const fetchTrips = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getAvailableTrips();
      setTrips(data.trips || []);
    } catch (err) {
      setError(err.detail || err.message || 'No se pudo conectar con el servidor');
    } finally {
      setLoading(false);
    }
  };

  if (loading && trips.length === 0) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Buscando cargas disponibles...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>⚠️ {error}</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.headerTitle}>🚛 Bolsa de Cargas (LogiFlete)</Text>
      
      <FlatList
        data={trips}
        keyExtractor={(item) => String(item.id)}
        onRefresh={fetchTrips}
        refreshing={loading}
        contentContainerStyle={styles.listContainer}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={styles.routeContainer}>
              <Text style={styles.city}>📍 {item.origin}</Text>
              <Text style={styles.arrow}>⬇</Text>
              <Text style={styles.city}>🏁 {item.destination}</Text>
            </View>
            
            <View style={styles.detailsContainer}>
              <Text style={styles.detailText}>📦 Carga: <Text style={styles.bold}>{item.cargo_type}</Text></Text>
              <Text style={styles.detailText}>⚖️ Peso: <Text style={styles.bold}>{item.weight_tons} Tons</Text></Text>
              <Text style={styles.detailText}>🚚 Acople: <Text style={styles.bold}>{item.required_trailer_type}</Text></Text>
            </View>

            <View style={styles.footerCard}>
              <Text style={styles.priceLabel}>Tarifa Ofrecida:</Text>
              <Text style={styles.priceValue}>${item.offered_price}</Text>
            </View>
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No hay fletes pendientes en este momento.</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f4f7' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  loadingText: { marginTop: 10, color: '#666' },
  errorText: { color: '#d9534f', textAlign: 'center', fontSize: 16 },
  headerTitle: { fontSize: 20, fontWeight: 'bold', textAlign: 'center', marginVertical: 16, color: '#1a1a1a' },
  listContainer: { paddingHorizontal: 16, paddingBottom: 20 },
  card: { backgroundColor: '#ffffff', borderRadius: 12, padding: 16, marginBottom: 16, elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4 },
  routeContainer: { borderBottomWidth: 1, borderBottomColor: '#eee', paddingBottom: 10, marginBottom: 10 },
  city: { fontSize: 16, fontWeight: '600', color: '#333' },
  arrow: { fontSize: 12, color: '#888', marginVertical: 2, paddingLeft: 4 },
  detailsContainer: { marginBottom: 12 },
  detailText: { fontSize: 14, color: '#555', marginBottom: 4 },
  bold: { fontWeight: 'bold', color: '#111' },
  footerCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderTopWidth: 1, borderTopColor: '#eee', paddingTop: 10 },
  priceLabel: { fontSize: 14, color: '#666' },
  priceValue: { fontSize: 18, fontWeight: 'bold', color: '#2e7d32' },
  emptyContainer: { alignItems: 'center', marginTop: 40 },
  emptyText: { color: '#888', fontSize: 15 }
});
