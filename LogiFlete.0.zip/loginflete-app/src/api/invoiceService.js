import client from './client';

export const registerInvoice = async (invoiceData) => {
  try {
    const response = await client.post('/invoices/', invoiceData);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.detail || 'Error al registrar la factura');
  }
};

export const registerTaxProfile = async (profileData) => {
  try {
    const response = await client.post('/invoices/tax-profile', profileData);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.detail || 'Error al registrar perfil fiscal');
  }
};
