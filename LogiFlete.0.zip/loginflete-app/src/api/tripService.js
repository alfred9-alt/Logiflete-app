import apiClient from './client';

// Obtener fletes pendientes
export const getAvailableTrips = async () => {
  try {
    const response = await apiClient.get('/trips/');
    return response.data;
  } catch (error) {
    throw error.response ? error.response.data : new Error('Error de conexión');
  }
};

// Publicar un nuevo flete
export const createTrip = async (tripData) => {
  try {
    const response = await apiClient.post('/trips/', tripData);
    return response.data;
  } catch (error) {
    throw error.response ? error.response.data : new Error('Error al publicar el viaje');
  }
};
