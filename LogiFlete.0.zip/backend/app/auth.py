from datetime import datetime, timedelta, timezone
from typing import Optional
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from dotenv import load_dotenv
import os

from app.database import get_db
from app.models import User

load_dotenv()

# Configuración de seguridad
SECRET_KEY = os.getenv("SECRET_KEY", "super_secret_jwt_key_change_in_production")
ALGORITHM = os.getenv("ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 1440))

# Contexto para hashear contraseñas con bcrypt
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Esquema OAuth2 para extraer el token Bearer de los headers
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")

router = APIRouter(prefix="/api/v1/auth", tags=["Autenticación y Usuarios"])

# --- ESQUEMAS PYDANTIC ---
class UserRegisterSchema(BaseModel):
    full_name: str = Field(..., min_length=3, max_length=120)
    phone: str = Field(..., min_length=6, max_length=30)
    password: str = Field(..., min_length=6)
    role: str = Field(..., pattern="^(DADOR_CARGA|TRANSPORTISTA)$")

class UserLoginSchema(BaseModel):
    phone: str
    password: str

# --- UTILIDADES DE CRIPTOGRAFÍA Y TOKENS ---
def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifica si la contraseña ingresada coincide con el hash almacenado."""
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    """Genera un hash seguro para la contraseña."""
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Crea un token JWT con tiempo de expiración."""
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_current_user(token: str = Depends(oauth2_scheme)):
    """Valida el token JWT enviado en las peticiones HTTP y extrae la identidad del usuario."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="No se pudieron validar las credenciales de acceso",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
        return user_id
    except JWTError:
        raise credentials_exception

# --- ENDPOINTS DE AUTENTICACIÓN ---
@router.post("/register", status_code=status.HTTP_201_CREATED)
def register_user(user_data: UserRegisterSchema, db: Session = Depends(get_db)):
    """Registra un nuevo usuario en la plataforma con contraseña hasheada."""
    clean_phone = user_data.phone.strip()
    existing_user = db.query(User).filter(User.phone == clean_phone).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El número de teléfono ya se encuentra registrado en el sistema."
        )
        
    hashed_password = get_password_hash(user_data.password)
    
    new_user = User(
        full_name=user_data.full_name.strip(),
        phone=clean_phone,
        password_hash=hashed_password,
        role=user_data.role
    )
        
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    return {
        "status": "success",
        "message": "Usuario registrado exitosamente.",
        "user_id": str(new_user.id),
        "role": new_user.role
    }

@router.post("/login", status_code=status.HTTP_200_OK)
def login_user(login_data: UserLoginSchema, db: Session = Depends(get_db)):
    """Autentica al usuario mediante teléfono y contraseña, retornando un Token JWT."""
    clean_phone = login_data.phone.strip()
    user = db.query(User).filter(User.phone == clean_phone).first()
        
    if not user or not verify_password(login_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciales incorrectas (teléfono o contraseña inválidos)."
        )
        
    access_token = create_access_token(data={"sub": str(user.id), "role": user.role})
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user_id": str(user.id),
        "role": user.role
    }
