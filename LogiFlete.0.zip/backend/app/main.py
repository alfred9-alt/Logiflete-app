from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Importamos la base de datos y los modelos para asegurar la creación de tablas
from app.database import engine, Base
from app.models import User, Truck, Trip, TripPayment

# Importamos todos los enrutadores desde app/routers/
from app.routers.auth import router as auth_router
from app.routers.trips import router as trips_router
from app.routers.trucks import router as trucks_router
from app.routers.payments import router as payments_router
from app.routers.invoices import router as invoices_router

# Inicialización de la aplicación FastAPI
app = FastAPI(
    title="LogiFlete API",
    version="1.0.0",
    description="Backend oficial de LogiFlete - Gestión de fletes y logística B2B/C2C"
)

# Configuración de CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # En producción, reemplazar por dominios permitidos
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Incluir todos los routers en la aplicación principal
app.include_router(auth_router)
app.include_router(trips_router)
app.include_router(trucks_router)
app.include_router(payments_router)
app.include_router(invoices_router)

@app.get("/api/v1/health", tags=["Estado del Sistema"])
def health_check():
    """
    Endpoint de verificación para comprobar que el backend y PostGIS responden correctamente.
    """
    return {
        "status": "online",
        "system": "LogiFlete Engine running with FastAPI, PostgreSQL & PostGIS",
        "version": "1.0.0"
    }
