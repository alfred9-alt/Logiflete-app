import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Float, Numeric, Date, DateTime, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from app.database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    full_name = Column(String(120), nullable=False)
    phone = Column(String(30), unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String(30), nullable=False)  # DADOR_CARGA | TRANSPORTISTA
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    trucks = relationship("Truck", back_populates="owner")
    trips_published = relationship("Trip", back_populates="shipper")
    tax_profile = relationship("UserTaxProfile", back_populates="user", uselist=False)


class Truck(Base):
    __tablename__ = "trucks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    owner_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    plate = Column(String(20), unique=True, index=True, nullable=False)  # Ej: AE123XY
    trailer_type = Column(String(50), nullable=False)  # BATEA, SIDER, CHASIS, PORTACONTENEDOR
    capacity_tons = Column(Float, nullable=False)
    is_active = Column(Boolean, default=True)

    owner = relationship("User", back_populates="trucks")


class Trip(Base):
    __tablename__ = "trips"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    shipper_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    origin = Column(String(200), nullable=False)
    destination = Column(String(200), nullable=False)
    cargo_type = Column(String(100), nullable=False)
    required_trailer_type = Column(String(50), nullable=False)
    weight_tons = Column(Float, nullable=False)
    offered_price = Column(Numeric(12, 2), nullable=False)
    status = Column(String(30), default="PENDIENTE", nullable=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    shipper = relationship("User", back_populates="trips_published")
    payment = relationship("TripPayment", back_populates="trip", uselist=False)


class TripPayment(Base):
    __tablename__ = "trip_payments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    trip_id = Column(UUID(as_uuid=True), ForeignKey("trips.id"), unique=True, nullable=False)
    total_amount = Column(Numeric(12, 2), nullable=False)
    advance_amount = Column(Numeric(12, 2), nullable=False)
    balance_amount = Column(Numeric(12, 2), nullable=False)
    status = Column(String(30), default="PENDING_ADVANCE", nullable=False)

    trip = relationship("Trip", back_populates="payment")


class UserTaxProfile(Base):
    __tablename__ = "user_tax_profiles"

    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), primary_key=True, default=uuid.uuid4)
    cuit = Column(String(11), unique=True, nullable=False)
    business_name = Column(String(150), nullable=False)
    tax_condition = Column(String(50), nullable=False)  # RESPONSABLE_INSCRIPTO, MONOTRIBUTO
    address = Column(String(255), nullable=True)

    user = relationship("User", back_populates="tax_profile")


class FreightInvoice(Base):
    __tablename__ = "freight_invoices"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    freight_id = Column(UUID(as_uuid=True), ForeignKey("trips.id"), nullable=False)
    issuer_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    invoice_type = Column(String(20), nullable=False)  # FACTURA_A, FACTURA_B, FACTURA_C
    point_of_sale = Column(Integer, nullable=False)
    invoice_number = Column(Integer, nullable=False)
    cae = Column(String(14), nullable=False)
    net_amount = Column(Numeric(12, 2), nullable=False)
    vat_amount = Column(Numeric(12, 2), default=0.00)
    total_amount = Column(Numeric(12, 2), nullable=False)
    issue_date = Column(Date, nullable=False)
    pdf_url = Column(String, nullable=True)
