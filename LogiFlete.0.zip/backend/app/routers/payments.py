from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Trip, TripPayment
from ..notifications import NotificationManager

router = APIRouter(prefix="/payments", tags=["Payments & Escrow"])

@router.post("/initialize/{trip_id}", status_code=status.HTTP_201_CREATED)
def initialize_trip_escrow(trip_id: int, db: Session = Depends(get_db)):
    """
    Calcula y registra los montos de custodia (30% anticipo, 70% saldo) 
    y descuenta automáticamente el 5% de comisión por el uso de la plataforma LogiFlete.
    """
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Viaje no encontrado.")
    
    total_price = float(trip.offered_price)
    
    # Cálculo de la comisión de la plataforma (5%)
    platform_fee = round(total_price * 0.05, 2)
    driver_net_total = round(total_price - platform_fee, 2)
    
    # Desglose del esquema Escrow sobre el total ofrecido
    advance_amount = round(total_price * 0.30, 2)  # 30% Anticipo
    balance_amount = round(total_price * 0.70, 2)  # 70% Contra entrega
    
    # Verificar si ya existe un registro de pago para este viaje
    existing_payment = db.query(TripPayment).filter(TripPayment.trip_id == trip_id).first()
    if existing_payment:
        return {
            "success": True, 
            "message": "El esquema Escrow ya está inicializado para este viaje.", 
            "payment": existing_payment
        }
    
    new_payment = TripPayment(
        trip_id=trip_id,
        total_amount=total_price,
        advance_amount=advance_amount,
        balance_amount=balance_amount,
        status="PENDING_ADVANCE"
    )
    
    db.add(new_payment)
    db.commit()
    db.refresh(new_payment)
    
    return {
        "success": True,
        "message": "Esquema de custodia Escrow 30/70 y comisión calculados con éxito.",
        "financial_summary": {
            "total_trip_price": total_price,
            "platform_fee_5_percent": platform_fee,
            "driver_net_total": driver_net_total,
            "advance_required_30_percent": advance_amount,
            "balance_remaining_70_percent": balance_amount
        }
    }

@router.post("/release-advance/{trip_id}")
def release_advance_payment(trip_id: int, db: Session = Depends(get_db)):
    """
    Simula el pago y liberación del 30% de anticipo para que el transportista comience el viaje.
    """
    payment = db.query(TripPayment).filter(TripPayment.trip_id == trip_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="No se encontró el registro de pago para este viaje.")

    if payment.status != "PENDING_ADVANCE":
        raise HTTPException(status_code=400, detail=f"El pago ya se encuentra en estado {payment.status}.")
    
    payment.status = "ADVANCE_PAID"
    db.commit()
    
    # Disparar notificación de pago en custodia
    NotificationManager.send_escrow_payment_alert(
        user_id=1, 
        trip_id=trip_id, 
        amount=payment.advance_amount, 
        percentage=30
    )
    
    return {
        "success": True,
        "message": "Anticipo del 30% liberado correctamente. El transportista puede iniciar la carga."
    }
