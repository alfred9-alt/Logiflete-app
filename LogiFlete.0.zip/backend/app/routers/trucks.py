from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import text
from pydantic import BaseModel
from ..database import get_db
from ..models import Truck

router = APIRouter(prefix="/trucks", tags=["Trucks"])

class TruckLocationUpdate(BaseModel):
    lat: float
    lng: float
    is_active: bool = True

@router.post("/", status_code=status.HTTP_201_CREATED)
def register_truck(plate: str, trailer_type: str, capacity_tons: float, owner_id: int, db: Session = Depends(get_db)):
    plate_clean = plate.upper().strip()

    # Verificar si la patente ya está registrada
    existing_truck = db.query(Truck).filter(Truck.plate == plate_clean).first()
    if existing_truck:
        raise HTTPException(status_code=400, detail="Este camión o patente ya se encuentra registrado.")
    
    new_truck = Truck(
        plate=plate_clean,
        trailer_type=trailer_type.upper().strip(),
        capacity_tons=capacity_tons,
        owner_id=owner_id
    )
    
    db.add(new_truck)
    db.commit()
    db.refresh(new_truck)
    
    return {
        "success": True,
        "message": "Camión registrado con éxito.",
        "truck_id": new_truck.id,
        "plate": new_truck.plate
    }

@router.get("/user/{owner_id}")
def get_user_trucks(owner_id: int, db: Session = Depends(get_db)):
    trucks = db.query(Truck).filter(Truck.owner_id == owner_id).all()
    return {"success": True, "count": len(trucks), "trucks": trucks}

@router.patch("/{truck_id}/location")
def update_truck_location(truck_id: int, loc: TruckLocationUpdate, db: Session = Depends(get_db)):
    truck = db.query(Truck).filter(Truck.id == truck_id).first()
    if not truck:
        raise HTTPException(status_code=404, detail="Camión no encontrado.")

    db.execute(
        text("""
            UPDATE trucks 
            SET current_location = ST_SetSRID(ST_MakePoint(:lng, :lat), 4326)::geography,
                is_active = :is_active
            WHERE id = :truck_id
        """),
        {"lng": loc.lng, "lat": loc.lat, "is_active": loc.is_active, "truck_id": truck_id}
    )
    db.commit()
    return {"success": True, "truck_id": truck_id, "lat": loc.lat, "lng": loc.lng}
