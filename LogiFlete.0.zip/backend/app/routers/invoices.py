from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field
from typing import Optional
from decimal import Decimal
from datetime import date
import uuid

router = APIRouter(
    prefix="/invoices",
    tags=["Facturación y Fiscal"]
)

class TaxProfileCreate(BaseModel):
    user_id: uuid.UUID
    cuit: str = Field(..., min_length=11, max_length=11)
    business_name: str
    tax_condition: str
    address: Optional[str] = None

class InvoiceCreate(BaseModel):
    freight_id: uuid.UUID
    issuer_id: uuid.UUID
    invoice_type: str
    point_of_sale: int = Field(..., ge=1)
    invoice_number: int = Field(..., ge=1)
    cae: str = Field(..., min_length=14, max_length=14)
    net_amount: Decimal = Field(..., ge=0)
    vat_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    total_amount: Decimal = Field(..., gt=0)
    issue_date: date
    pdf_url: Optional[str] = None

@router.post("/tax-profile", status_code=status.HTTP_201_CREATED)
def create_tax_profile(profile: TaxProfileCreate):
    """Registra o actualiza el perfil fiscal del usuario."""
    return {
        "status": "success",
        "message": "Perfil fiscal registrado correctamente.",
        "data": profile.model_dump()
    }

@router.post("/", status_code=status.HTTP_201_CREATED)
def register_invoice(invoice: InvoiceCreate):
    """Registra la factura asociada al flete validando consistencia de importes."""
    if abs((invoice.net_amount + invoice.vat_amount) - invoice.total_amount) > Decimal("0.05"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El monto neto más el IVA no coincide con el monto total."
        )

    return {
        "status": "success",
        "message": "Factura validada y asociada con éxito.",
        "invoice_number": f"{invoice.point_of_sale:04d}-{invoice.invoice_number:08d}"
    }
