from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
import datetime

from app.database import get_db
from app.models import Trip, TripPayment, User

router = APIRouter(prefix="/api/v1/trips", tags=["Viajes y Fletes"])

class TripCreateSchema(BaseModel):
    origin: str
    destination: str
    cargo_type: str
    required_trailer_type: str  # Ej: 'BATEA', 'SIDER'
    weight_tons: float
    offered_price: float
    origin_lat: float
    origin_lng: float

@router.get("/", status_code=status.HTTP_200_OK)
def get_available_trips(db: Session = Depends(get_db)):
    """
    Retorna todos los viajes que se encuentran pendientes de asignación en la bolsa de cargas.
    """
    trips = db.query(Trip).filter(Trip.status == 'PENDIENTE').all()
    return {"status": "success", "count": len(trips), "trips": trips}

@router.post("/", status_code=status.HTTP_201_CREATED)
def create_trip(
    trip_data: TripCreateSchema,
    db: Session = Depends(get_db)
):
    """
    Permite a un dador de carga publicar un nuevo flete en la plataforma.
    """
    try:
        first_user = db.query(User).filter(User.role == 'DADOR_CARGA').first()
        shipper_uuid = first_user.id if first_user else None

        if not shipper_uuid:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Se requiere al menos un usuario con rol DADOR_CARGA en el sistema para publicar."
            )

        new_trip = Trip(
            shipper_id=shipper_uuid,
            origin=trip_data.origin,
            destination=trip_data.destination,
            cargo_type=trip_data.cargo_type,
            required_trailer_type=trip_data.required_trailer_type,
            weight_tons=trip_data.weight_tons,
            offered_price=trip_data.offered_price,
            status='PENDIENTE'
        )
        
        db.add(new_trip)
        db.flush()  # Para obtener el ID generado del viaje

        # Inicializar el registro financiero de custodia (Escrow 30/70)
        advance_val = round(trip_data.offered_price * 0.30, 2)
        balance_val = round(trip_data.offered_price * 0.70, 2)
        
        new_payment = TripPayment(
            trip_id=new_trip.id,
            total_amount=trip_data.offered_price,
            advance_amount=advance_val,
            balance_amount=balance_val,
            status='PENDIENTE_ANTICIPO'
        )
        
        db.add(new_payment)
        db.commit()
        db.refresh(new_trip)
        
        return {
            "status": "success",
            "message": "Viaje publicado con éxito y registrado en el sistema de custodia.",
            "trip_id": str(new_trip.id)
        }
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error al procesar la publicación del viaje: {str(e)}"
        )
