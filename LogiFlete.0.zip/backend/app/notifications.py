from datetime import datetime, timezone
from typing import Union
import uuid

class NotificationManager:
    """
    Gestor centralizado de notificaciones para LogiFlete.
    Permite enviar alertas por cambios de estado en los viajes,
    pagos de custodia o asignación de transportistas.
    """
    
    @staticmethod
    def send_trip_status_alert(user_id: Union[int, str, uuid.UUID], trip_id: Union[int, str, uuid.UUID], status: str):
        # Aquí puedes integrar la lógica de Firebase Cloud Messaging (FCM) o WebSockets
        timestamp = datetime.now(timezone.utc).isoformat()
        print(f"[NOTIFICACIÓN PUSH] Usuario {user_id} -> El viaje #{trip_id} cambió al estado: {status} a las {timestamp}")
        
        return {
            "success": True,
            "user_id": str(user_id),
            "message": f"Su viaje pasó a estado: {status}",
            "timestamp": timestamp
        }

    @staticmethod
    def send_escrow_payment_alert(user_id: Union[int, str, uuid.UUID], trip_id: Union[int, str, uuid.UUID], amount: float, percentage: int):
        print(f"[PAGO ESCROW] Alerta para usuario {user_id}: Se procesó el {percentage}% de custodia ($ {amount}) para el viaje #{trip_id}")
        return {
            "success": True,
            "user_id": str(user_id),
            "message": f"Pago en custodia de {percentage}% por $ {amount} registrado con éxito.",
        }
