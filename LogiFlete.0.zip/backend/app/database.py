from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
import os
from dotenv import load_dotenv

load_dotenv()

# URL de conexión obtenida desde el archivo .env o variables de Railway
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://logiflete_admin:secure_password_123@localhost:5432/logiflete_db"
)

# Compatibilidad con URLs antiguas tipo postgres:// en servicios cloud (ej. Railway/Heroku)
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

# Dependencia para inyectar la sesión de base de datos en los endpoints de FastAPI
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
