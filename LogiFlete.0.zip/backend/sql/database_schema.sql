-- 0. Asegurar extensión para gen_random_uuid() y PostGIS
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. Tipo de Condición Fiscal
CREATE TYPE tax_condition AS ENUM (
    'RESPONSABLE_INSCRIPTO',
    'MONOTRIBUTO',
    'EXENTO',
    'CONSUMIDOR_FINAL'
);

-- 2. Tipo de Comprobante
CREATE TYPE invoice_type AS ENUM (
    'FACTURA_A',
    'FACTURA_B',
    'FACTURA_C',
    'NOTA_DEBITO',
    'NOTA_CREDITO'
);

-- 3. Tabla de Perfiles Fiscales de Usuarios (Transportistas / Empresas)
CREATE TABLE user_tax_profiles (
    user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    cuit VARCHAR(11) UNIQUE NOT NULL,
    business_name VARCHAR(150) NOT NULL,
    tax_condition tax_condition NOT NULL,
    address TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Tabla de Facturas asociadas a los Viajes (trips)
CREATE TABLE freight_invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    freight_id UUID NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
    issuer_id UUID NOT NULL REFERENCES users(id),
    invoice_type invoice_type NOT NULL,
    point_of_sale INT NOT NULL,
    invoice_number INT NOT NULL,
    cae VARCHAR(14) NOT NULL,
    net_amount NUMERIC(12, 2) NOT NULL,
    vat_amount NUMERIC(12, 2) DEFAULT 0.00,
    total_amount NUMERIC(12, 2) NOT NULL,
    issue_date DATE NOT NULL,
    pdf_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_invoice UNIQUE (issuer_id, point_of_sale, invoice_number)
);

-- 5. Trigger PL/pgSQL para validar que el monto de la factura coincida con el viaje acordado
CREATE OR REPLACE FUNCTION validate_invoice_amount_func()
RETURNS TRIGGER AS $$
DECLARE
    v_agreed_amount NUMERIC(12, 2);
BEGIN
    SELECT offered_price INTO v_agreed_amount
    FROM trips
    WHERE id = NEW.freight_id;

    IF v_agreed_amount IS NULL THEN
        RAISE EXCEPTION 'El viaje asociado ID % no existe.', NEW.freight_id;
    END IF;

    -- Tolerancia de $0.05 por redondeo de IVA 21%
    IF ABS(NEW.total_amount - v_agreed_amount) > 0.05 THEN
        RAISE EXCEPTION 'El monto total de la factura (%) no coincide con el acordado en el viaje (%).',
                        NEW.total_amount, v_agreed_amount;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_validate_invoice_amount
    BEFORE INSERT OR UPDATE ON freight_invoices
    FOR EACH ROW
    EXECUTE FUNCTION validate_invoice_amount_func();
