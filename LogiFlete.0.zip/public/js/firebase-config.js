// public/js/firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";
import { getMessaging, getToken, isSupported } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging.js";

// Configuración real de tu proyecto Firebase (Logiflete-web)
const firebaseConfig = {
  apiKey: "AIzaSyDYpmcNuTMlgnP6L-GsrCZ2QB0m-3kf00o",
  authDomain: "logiflete-41b77.firebaseapp.com",
  projectId: "logiflete-41b77",
  storageBucket: "logiflete-41b77.firebasestorage.app",
  messagingSenderId: "423315901427",
  appId: "1:423315901427:web:828472595855f7d24c2086",
  measurementId: "G-X20YPC7RR8"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);

// Exportar servicios para toda la app
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

// Inicializar Messaging solo si el navegador lo soporta
let messagingInstance = null;
isSupported().then((supported) => {
  if (supported) {
    messagingInstance = getMessaging(app);
  }
}).catch(() => {});

export const messaging = messagingInstance;

// Solicitar permiso y obtener token FCM del dispositivo
export async function obtenerTokenNotificaciones() {
  try {
    const soportado = await isSupported();
    if (!soportado || !("Notification" in window)) return null;

    if (!messagingInstance) {
      messagingInstance = getMessaging(app);
    }

    const permiso = await Notification.requestPermission();
    if (permiso === "granted") {
      const token = await getToken(messagingInstance, {
        vapidKey: "TU_CLAVE_VAPID_DE_FIREBASE_MESSAGING"
      });
      return token;
    }
    return null;
  } catch (error) {
    console.error("Error al obtener token de notificaciones:", error);
    return null;
  }
}
