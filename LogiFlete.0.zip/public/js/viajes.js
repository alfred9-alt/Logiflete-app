// public/js/viajes.js
import { db, storage, auth } from "./firebase-config.js";
import { 
  doc, 
  updateDoc, 
  serverTimestamp 
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { 
  ref, 
  uploadBytes, 
  getDownloadURL 
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";

/**
 * Comprime la foto tomada desde el celular para que pese menos de 1MB
 * sin perder legibilidad en los datos del remito.
 */
function comprimirImagen(archivo, maxWidth = 1280, calidad = 0.75) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(archivo);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target.result;
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;

        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(blob);
            } else {
              reject(new Error("Error al comprimir la imagen."));
            }
          },
          "image/jpeg",
          calidad
        );
      };
      img.onerror = (err) => reject(err);
    };
    reader.onerror = (err) => reject(err);
  });
}

/**
 * Sube la foto del remito a Firebase Storage y actualiza el viaje en Firestore.
 * @param {string} viajeId - ID del documento en la colección 'viajes'
 * @param {File} archivoFoto - Archivo obtenido del <input type="file">
 */
export async function subirRemitoYFinalizarEntrega(viajeId, archivoFoto) {
  const usuario = auth.currentUser;
  if (!usuario) {
    throw new Error("Debes iniciar sesión para subir el remito.");
  }

  if (!archivoFoto || !archivoFoto.type.startsWith("image/")) {
    throw new Error("Por favor selecciona o toma una foto válida del remito.");
  }

  try {
    // 1. Comprimir foto para subida rápida en ruta (4G/datos móviles)
    const imagenComprimida = await comprimirImagen(archivoFoto);

    // 2. Definir ruta exacta que coincide con storage.rules: remitos/{viajeId}/{nombreArchivo}
    const nombreArchivo = `remito_${Date.now()}.jpg`;
    const storageRef = ref(storage, `remitos/${viajeId}/${nombreArchivo}`);

    // 3. Subir archivo a Firebase Storage
    const snapshot = await uploadBytes(storageRef, imagenComprimida, {
      contentType: "image/jpeg"
    });

    // 4. Obtener la URL de descarga segura
    const downloadURL = await getDownloadURL(snapshot.ref);

    // 5. Actualizar Firestore (coincide exactamente con los campos permitidos en firestore.rules)
    const viajeRef = doc(db, "viajes", viajeId);
    await updateDoc(viajeRef, {
      estado: "remito_subido",
      evidenciaEntrega: {
        remitoUrl: downloadURL,
        remitoVerificado: false,
        fechaSubida: serverTimestamp(),
        fechaAprobacion: null
      }
    });

    return {
      ok: true,
      url: downloadURL,
      mensaje: "Remito subido correctamente. Esperando aprobación del dador de carga para liberar el saldo."
    };

  } catch (error) {
    console.error("Error en subirRemitoYFinalizarEntrega:", error);
    throw error;
  }
}

/**
 * Función para el Dador de Carga: Aprueba el remito subido.
 * Esto dispara la lógica de liberación del 65% restante (70% - 5% comisión).
 */
export async function aprobarRemitoDador(viajeId) {
  const usuario = auth.currentUser;
  if (!usuario) throw new Error("Usuario no autenticado.");

  try {
    const viajeRef = doc(db, "viajes", viajeId);
    await updateDoc(viajeRef, {
      estado: "completado",
      "evidenciaEntrega.remitoVerificado": true,
      "evidenciaEntrega.fechaAprobacion": serverTimestamp(),
      "timestamps.finalizadoAt": serverTimestamp()
    });

    return {
      ok: true,
      mensaje: "Entrega aprobada. Se ha notificado para liberar el saldo final al transportista."
    };
  } catch (error) {
    console.error("Error al aprobar remito:", error);
    throw error;
  }
}
