// public/js/auth.js
import { auth, db, obtenerTokenNotificaciones } from "./firebase-config.js";
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged 
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  serverTimestamp 
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

/**
 * Valida formato básico de CUIT argentino (11 dígitos)
 */
function validarCuit(cuit) {
  const limpio = cuit.replace(/[^0-9]/g, "");
  return limpio.length === 11;
}

/**
 * Registra un nuevo usuario (Dador de Carga o Transportista) en Auth y Firestore
 * @param {Object} datos - Datos del formulario de registro
 */
export async function registrarUsuario(datos) {
  const {
    email,
    password,
    role, // "dador_carga" | "transportista"
    nombreCompleto,
    telefono,
    cuit,
    condicionIva, // "monotributo" | "responsable_inscripto"
    razonSocial,
    // Datos opcionales (solo si role === "transportista")
    tipoVehiculo,
    capacidadKg,
    patente
  } = datos;

  if (!validarCuit(cuit)) {
    throw new Error("El CUIT debe tener 11 dígitos válidos.");
  }

  try {
    // 1. Crear cuenta en Firebase Authentication
    const credencial = await createUserWithEmailAndPassword(auth, email, password);
    const uid = credencial.user.uid;

    // 2. Intentar obtener token de notificaciones push
    const fcmToken = await obtenerTokenNotificaciones();

    // 3. Armar estructura base del perfil (coincide con firestore.rules)
    const perfilUsuario = {
      uid,
      role,
      nombreCompleto,
      telefono,
      fcmToken: fcmToken || null,
      datosFiscales: {
        cuit: cuit.replace(/[^0-9]/g, ""),
        condicionIva,
        razonSocial: razonSocial || nombreCompleto
      },
      createdAt: serverTimestamp()
    };

    // 4. Si es transportista, agregar datos iniciales de su unidad
    if (role === "transportista") {
      perfilUsuario.flota = {
        disponible: true,
        tipoVehiculo: tipoVehiculo || "chasis",
        capacidadKg: Number(capacidadKg) || 0,
        patente: (patente || "").toUpperCase().trim(),
        ubicacionActual: null
      };
    }

    // 5. Guardar documento en colección 'users'
    await setDoc(doc(db, "users", uid), perfilUsuario);

    return { ok: true, uid, role };
  } catch (error) {
    console.error("Error en registrarUsuario:", error);
    throw error;
  }
}

/**
 * Inicia sesión y actualiza el token de notificaciones push del dispositivo
 */
export async function iniciarSesion(email, password) {
  try {
    const credencial = await signInWithEmailAndPassword(auth, email, password);
    const uid = credencial.user.uid;

    const userRef = doc(db, "users", uid);
    const userSnap = await getDoc(userRef);

    if (!userSnap.exists()) {
      throw new Error("No se encontró el perfil del usuario en la base de datos.");
    }

    const userData = userSnap.data();

    // Actualizar token FCM en cada inicio de sesión por si cambió de teléfono
    const nuevoToken = await obtenerTokenNotificaciones();
    if (nuevoToken && nuevoToken !== userData.fcmToken) {
      await updateDoc(userRef, { fcmToken: nuevoToken });
    }

    return { ok: true, uid, role: userData.role, perfil: userData };
  } catch (error) {
    console.error("Error en iniciarSesion:", error);
    throw error;
  }
}

/**
 * Cierra sesión y redirige al login
 */
export async function cerrarSesion() {
  await signOut(auth);
  window.location.href = "/index.html";
}

/**
 * Cambia el estado de disponibilidad del transportista ("Disponible" / "Ocupado")
 */
export async function cambiarDisponibilidadFlota(disponible) {
  const usuario = auth.currentUser;
  if (!usuario) throw new Error("Usuario no autenticado.");

  const userRef = doc(db, "users", usuario.uid);
  await updateDoc(userRef, {
    "flota.disponible": Boolean(disponible)
  });
}

/**
 * Protege las vistas privadas (dashboards) y devuelve los datos del usuario logueado
 * @param {string} rolRequerido - Opcional: "transportista" o "dador_carga"
 * @param {Function} onReady - Callback que recibe (user, perfilFirestore)
 */
export function verificarAcceso(rolRequerido, onReady) {
  onAuthStateChanged(auth, async (user) => {
    if (!user) {
      window.location.href = "/index.html";
      return;
    }

    const userSnap = await getDoc(doc(db, "users", user.uid));
    if (!userSnap.exists()) {
      await cerrarSesion();
      return;
    }

    const perfil = userSnap.data();

    // Si entra al panel equivocado, lo redirige al suyo
    if (rolRequerido && perfil.role !== rolRequerido) {
      window.location.href =
        perfil.role === "transportista"
          ? "/views/dashboard-chofer.html"
          : "/views/dashboard-dador.html";
      return;
    }

    onReady(user, perfil);
  });
}
