export async function aceptarPostulante(postulacionId, cargaId, transportistaId) {
  const usuario = auth.currentUser;
  if (!usuario) throw new Error("Debes iniciar sesión.");

  const postulacionRef = doc(db, "postulaciones", postulacionId);

  try {
    // Marcar la postulación como aceptada
    await updateDoc(postulacionRef, {
      estado: "aceptada"
    });

    // Invocar Cloud Function 'asignarViajeYCrearEscrow'
    const asignarViajeFn = httpsCallable(functions, "asignarViajeYCrearEscrow");
    const resultado = await asignarViajeFn({ cargaId, transportistaId });

    return {
      ok: true,
      viajeId: resultado.data.viajeId,
      mensaje: "Transportista asignado. Ya puedes realizar el depósito del 30% de adelanto."
    };
  } catch (error) {
    // Si falla la Cloud Function, revertir estado para no dejar la postulación inconsistente
    try {
      await updateDoc(postulacionRef, { estado: "pendiente" });
    } catch (_) {}
    console.error("Error al aceptar postulante:", error);
    throw error;
  }
}
