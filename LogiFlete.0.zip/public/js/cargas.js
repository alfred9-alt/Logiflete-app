// public/js/cargas.js
import { db, auth } from "./firebase-config.js";
import {
  collection,
  addDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

/**
 * Publica una nueva carga en Firestore (Dador de Carga).
 * Coincide con la estructura esperada por dashboard.dador.html y dashboard.chofer.html.
 */
export async function publicarCarga(datos) {
  const usuario = auth.currentUser;
  if (!usuario) {
    throw new Error("Debes iniciar sesión para publicar una carga.");
  }

  const {
    origenLocalidad,
    destinoLocalidad,
    tipoCarga,
    pesoKg,
    vehiculoRequerido,
    montoTotal
  } = datos;

  const pesoNumerico = Number(pesoKg);
  const montoNumerico = Number(montoTotal);

  if (!origenLocalidad || !destinoLocalidad || !tipoCarga) {
    throw new Error("Origen, destino y tipo de mercadería son obligatorios.");
  }
  if (isNaN(pesoNumerico) || pesoNumerico <= 0) {
    throw new Error("El peso debe ser mayor a 0 kg.");
  }
  if (isNaN(montoNumerico) || montoNumerico <= 0) {
    throw new Error("La tarifa ofrecida debe ser mayor a $ 0.");
  }

  const nuevaCarga = {
    dadorId: usuario.uid,
    estado: "publicada", // "publicada" | "asignada" | "cancelada"
    origen: {
      localidad: origenLocalidad.trim()
    },
    destino: {
      localidad: destinoLocalidad.trim()
    },
    detalleCarga: {
      tipo: tipoCarga.trim(),
      pesoKg: pesoNumerico
    },
    vehiculoRequerido: vehiculoRequerido || "chasis_con_acoplado",
    tarifa: {
      montoTotal: montoNumerico,
      moneda: "ARS"
    },
    createdAt: serverTimestamp()
  };

  const docRef = await addDoc(collection(db, "cargas"), nuevaCarga);
  return {
    ok: true,
    cargaId: docRef.id,
    mensaje: "Carga publicada con éxito."
  };
}

/**
 * Escucha en tiempo real las cargas disponibles compatibles con el vehículo del transportista.
 * @param {string} tipoVehiculo - Ej: "utilitario" | "chasis" | "semi" | "chasis_con_acoplado"
 * @param {Function} callback - Recibe el array de cargas compatibles
 */
export function escucharCargasDisponibles(tipoVehiculo, callback) {
  const condiciones = [where("estado", "==", "publicada")];

  if (tipoVehiculo) {
    condiciones.push(where("vehiculoRequerido", "==", tipoVehiculo));
  }

  const q = query(
    collection(db, "cargas"),
    ...condiciones,
    orderBy("createdAt", "desc")
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const cargas = [];
      snapshot.forEach((docSnap) => {
        cargas.push({ id: docSnap.id, ...docSnap.data() });
      });
      callback(cargas);
    },
    (error) => {
      console.error("Error escuchando cargas disponibles:", error);
      callback([]);
    }
  );
}

/**
 * Escucha en tiempo real todas las cargas publicadas por el Dador de Carga logueado.
 * @param {Function} callback - Recibe el array de cargas del dador
 */
export function escucharMisCargasDador(callback) {
  const usuario = auth.currentUser;
  if (!usuario) return null;

  const q = query(
    collection(db, "cargas"),
    where("dadorId", "==", usuario.uid),
    orderBy("createdAt", "desc")
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const misCargas = [];
      snapshot.forEach((docSnap) => {
        misCargas.push({ id: docSnap.id, ...docSnap.data() });
      });
      callback(misCargas);
    },
    (error) => {
      console.error("Error escuchando mis cargas:", error);
      callback([]);
    }
  );
}
