// public/js/pagos.js
import { db, auth } from "./firebase-config.js";
import { 
  doc, 
  getDoc, 
  onSnapshot 
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

/**
 * Calcula el desglose completo de un flete considerando reglas de Escrow (30% / 5%)
 * y la condición fiscal frente al IVA en Argentina.
 *
 * @param {number} montoBaseFlete - Tarifa neta acordada por el viaje (en ARS)
 * @param {string} condicionIvaTransportista - "monotributo" | "responsable_inscripto"
 * @param {string} condicionIvaDador - "monotributo" | "responsable_inscripto"
 * @returns {Object} Desglose detallado listo para mostrar en UI o enviar al backend
 */
export function calcularDesgloseFlete(
  montoBaseFlete,
  condicionIvaTransportista,
  condicionIvaDador = "responsable_inscripto"
) {
  const montoNeto = Number(montoBaseFlete);
  if (isNaN(montoNeto) || montoNeto <= 0) {
    throw new Error("El monto base del flete debe ser mayor a 0.");
  }

  // 1. Lógica Fiscal (AFIP / ARCA)
  // Si el transportista es Responsable Inscripto, se agrega 21% de IVA al monto del flete.
  // Si es Monotributista, el monto es final (exento de discriminar IVA).
  const esTransportistaRI = condicionIvaTransportista === "responsable_inscripto";
  const esDadorRI = condicionIvaDador === "responsable_inscripto";

  const alicuotaIva = esTransportistaRI ? 0.21 : 0;
  const montoIva = Math.round(montoNeto * alicuotaIva);
  const totalConImpuestos = montoNeto + montoIva;

  // Tipo de comprobante que deberá subir el transportista
  let tipoFacturaRequerida = "C";
  if (esTransportistaRI) {
    tipoFacturaRequerida = esDadorRI ? "A" : "B";
  }

  // 2. Lógica de Escrow y Comisiones (sobre el monto neto del flete)
  const PCT_COMISION = 0.05; // 5% plataforma
  const PCT_ADELANTO = 0.30; // 30% al iniciar viaje

  const comisionPlataforma = Math.round(montoNeto * PCT_COMISION);
  const adelantoTransportista = Math.round(totalConImpuestos * PCT_ADELANTO);
  
  // El saldo final es el total menos el adelanto ya entregado y menos la comisión de LogiFlete
  const saldoFinalTransportista = totalConImpuestos - adelantoTransportista - comisionPlataforma;

  return {
    moneda: "ARS",
    fiscal: {
      condicionTransportista: condicionIvaTransportista,
      tipoFacturaRequerida, // "A", "B" o "C"
      montoNetoFlete: montoNeto,
      iva21: montoIva,
      totalAPagarDador: totalConImpuestos
    },
    escrow: {
      porcentajeAdelanto: "30%",
      montoAdelanto: adelantoTransportista,       // Se libera al iniciar viaje
      porcentajeComision: "5%",
      comisionLogiFlete: comisionPlataforma,      // Retención de la plataforma
      saldoFinalAlAprobarRemito: saldoFinalTransportista // Se libera tras remito aprobado
    }
  };
}

/**
 * Formatea números a moneda argentina ($ 1.000.000) para mostrar en las tarjetas
 */
export function formatearPesos(monto) {
  return new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
    maximumFractionDigits: 0
  }).format(monto);
}

/**
 * Escucha en tiempo real el estado del pago en garantía (Escrow) de un viaje
 * @param {string} pagoId - ID del documento en la colección 'pagos'
 * @param {Function} callback - Función que recibe los datos actualizados para pintar el HTML
 */
export function suscribirEstadoPago(pagoId, callback) {
  if (!auth.currentUser) return null;

  const pagoRef = doc(db, "pagos", pagoId);
  return onSnapshot(
    pagoRef,
    (docSnap) => {
      if (docSnap.exists()) {
        callback({ id: docSnap.id, ...docSnap.data() });
      } else {
        callback(null);
      }
    },
    (error) => {
      console.error("Error escuchando estado del pago:", error);
    }
  );
}
