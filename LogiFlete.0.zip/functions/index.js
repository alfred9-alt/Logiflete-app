// functions/index.js
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();

exports.asignarViajeYCrearEscrow = onCall(async (request) => {
  // 1. Verificar autenticación
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Debes iniciar sesión para asignar un viaje.");
  }

  const dadorUid = request.auth.uid;
  const { cargaId, transportistaId } = request.data;

  if (!cargaId || !transportistaId) {
    throw new HttpsError("invalid-argument", "Faltan parámetros: cargaId y transportistaId.");
  }

  const cargaRef = db.collection("cargas").doc(cargaId);
  const dadorRef = db.collection("users").doc(dadorUid);
  const choferRef = db.collection("users").doc(transportistaId);
  const nuevoViajeRef = db.collection("viajes").doc(); // ID automático para viaje y pago
  const nuevoPagoRef = db.collection("pagos").doc(nuevoViajeRef.id);

  let fcmTokenChofer = null;
  let rutaResumen = "";

  // 2. Ejecutar transacción atómica en Firestore
  await db.runTransaction(async (tx) => {
    const [cargaSnap, dadorSnap, choferSnap] = await Promise.all([
      tx.get(cargaRef),
      tx.get(dadorRef),
      tx.get(choferRef)
    ]);

    if (!cargaSnap.exists) {
      throw new HttpsError("not-found", "La carga especificada no existe.");
    }
    if (!choferSnap.exists) {
      throw new HttpsError("not-found", "El perfil del transportista no existe.");
    }

    const carga = cargaSnap.data();
    const dador = dadorSnap.exists ? dadorSnap.data() : {};
    const chofer = choferSnap.data();

    if (carga.dadorId !== dadorUid) {
      throw new HttpsError("permission-denied", "No tenés permiso para asignar esta carga.");
    }
    if (carga.estado !== "publicada") {
      throw new HttpsError("failed-precondition", "Esta carga ya fue asignada o cancelada.");
    }

    // 3. Cálculos Fiscales (ARCA/AFIP) y Escrow (30% adelanto / 5% comisión)
    const montoNeto = Number(carga.tarifa?.montoTotal || 0);
    const ivaChofer = chofer.datosFiscales?.condicionIva || "monotributo";
    const ivaDador = dador.datosFiscales?.condicionIva || "responsable_inscripto";

    const esChoferRI = ivaChofer === "responsable_inscripto";
    const esDadorRI = ivaDador === "responsable_inscripto";

    const montoIva = esChoferRI ? Math.round(montoNeto * 0.21) : 0;
    const totalConImpuestos = montoNeto + montoIva;

    let tipoComprobante = "C";
    if (esChoferRI) {
      tipoComprobante = esDadorRI ? "A" : "B";
    }

    const comisionLogiFlete = Math.round(montoNeto * 0.05);
    const montoAdelanto = Math.round(totalConImpuestos * 0.30);
    const montoSaldoFinal = totalConImpuestos - montoAdelanto - comisionLogiFlete;

    fcmTokenChofer = chofer.fcmToken || null;
    rutaResumen = `${carga.origen?.localidad} → ${carga.destino?.localidad}`;

    // 4. Crear documento del Viaje
    tx.set(nuevoViajeRef, {
      cargaId,
      dadorId: dadorUid,
      transportistaId,
      origen: carga.origen,
      destino: carga.destino,
      detalleCarga: carga.detalleCarga,
      estado: "pendiente_adelanto", // "pendiente_adelanto" | "en_curso" | "remito_subido" | "completado"
      facturacion: {
        tipoComprobante,
        cuitEmisor: chofer.datosFiscales?.cuit || "",
        condicionIvaEmisor: ivaChofer
      },
      evidenciaEntrega: {
        remitoUrl: null,
        remitoVerificado: false,
        fechaSubida: null,
        fechaAprobacion: null
      },
      timestamps: {
        asignadoAt: admin.firestore.FieldValue.serverTimestamp(),
        finalizadoAt: null
      }
    });

    // 5. Crear documento de Pago en Custodia (Escrow) con el mismo ID del viaje
    tx.set(nuevoPagoRef, {
      viajeId: nuevoViajeRef.id,
      cargaId,
      dadorId: dadorUid,
      transportistaId,
      estadoEscrow: "pendiente_deposito_adelanto", // "pendiente_deposito_adelanto" | "adelanto_liberado" | "saldo_liberado"
      desglose: {
        montoNetoFlete: montoNeto,
        iva21: montoIva,
        totalAPagarDador: totalConImpuestos,
        montoAdelanto,
        comisionLogiFlete,
        montoSaldoFinal
      },
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });

    // 6. Marcar carga como asignada y poner al transportista como ocupado
    tx.update(cargaRef, {
      estado: "asignada",
      transportistaAsignadoId: transportistaId,
      viajeId: nuevoViajeRef.id
    });

    tx.update(choferRef, {
      "flota.disponible": false
    });
  });

  // 7. Rechazar las demás postulaciones pendientes de esa misma carga
  const otrasPostulaciones = await db
    .collection("postulaciones")
    .where("cargaId", "==", cargaId)
    .where("estado", "==", "pendiente")
    .get();

  if (!otrasPostulaciones.empty) {
    const batch = db.batch();
    otrasPostulaciones.forEach((docSnap) => {
      if (docSnap.data().transportistaId !== transportistaId) {
        batch.update(docSnap.ref, { estado: "rechazada" });
      }
    });
    await batch.commit();
  }

  // 8. Enviar Notificación Push (FCM) al transportista si tiene token registrado
  if (fcmTokenChofer) {
    try {
      await admin.messaging().send({
        token: fcmTokenChofer,
        notification: {
          title: "¡Te asignaron un viaje en LogiFlete!",
          body: `Viaje confirmado: ${rutaResumen}. Esperando depósito del 30% de adelanto.`
        },
        data: {
          viajeId: nuevoViajeRef.id,
          tipo: "VIAJE_ASIGNADO"
        }
      });
    } catch (fcmError) {
      console.warn("No se pudo enviar push FCM al chofer:", fcmError.message);
    }
  }

  return {
    ok: true,
    viajeId: nuevoViajeRef.id
  };
});
